/**!
 * FileAPI — a set of tools for working with files
 *
 * @author  RubaXa  <trash@rubaxa.org>
 * @build	lib/canvas-to-blob lib/FileAPI.core lib/FileAPI.Image lib/FileAPI.Form lib/FileAPI.XHR lib/FileAPI.Flash
 */
