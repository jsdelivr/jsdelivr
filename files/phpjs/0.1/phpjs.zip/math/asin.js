function asin (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: asin(0.3);
  // *     returns 1: 0.3046926540153975
  return Math.asin(arg);
}
