function sqrt (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: sqrt(8723321.4);
  // *     returns 1: 2953.5269424875746
  return Math.sqrt(arg);
}
