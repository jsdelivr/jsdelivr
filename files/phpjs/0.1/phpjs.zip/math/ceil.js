function ceil (value) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: ceil(8723321.4);
  // *     returns 1: 8723322
  return Math.ceil(value);
}
