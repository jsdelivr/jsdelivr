function pow (base, exp) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: pow(8723321.4, 7);
  // *     returns 1: 3.843909168077899e+48
  return Math.pow(base, exp);
}
