function sin (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: sin(8723321.4);
  // *     returns 1: -0.9834330348825909
  return Math.sin(arg);
}
