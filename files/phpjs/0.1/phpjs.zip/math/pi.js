function pi () {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // +   improved by: dude
  // *     example 1: pi(8723321.4);
  // *     returns 1: 3.141592653589793
  return 3.141592653589793; // Math.PI
}
