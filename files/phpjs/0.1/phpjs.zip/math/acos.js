function acos (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: acos(0.3);
  // *     returns 1: 1.2661036727794992
  return Math.acos(arg);
}
