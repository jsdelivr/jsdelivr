function exp (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: exp(0.3);
  // *     returns 1: 1.3498588075760032
  return Math.exp(arg);
}
