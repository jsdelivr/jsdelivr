function tan (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: tan(8723321.4);
  // *     returns 1: 5.4251848798444815
  return Math.tan(arg);
}
