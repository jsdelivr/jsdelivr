function lcg_value () {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  return Math.random();
}
