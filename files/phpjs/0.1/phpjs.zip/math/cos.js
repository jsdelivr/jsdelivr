function cos (arg) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: cos(8723321.4);
  // *     returns 1: -0.18127180117607017
  return Math.cos(arg);
}
