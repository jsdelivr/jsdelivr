function floor (value) {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: floor(8723321.4);
  // *     returns 1: 8723321
  return Math.floor(value);
}
