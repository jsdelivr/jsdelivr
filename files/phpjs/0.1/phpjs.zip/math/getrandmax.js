function getrandmax () {
  // http://kevin.vanzonneveld.net
  // +   original by: Onno Marsman
  // *     example 1: getrandmax();
  // *     returns 1: 2147483647
  return 2147483647;
}
