define( {
	'jgrid.locale' : 'en',
	'button.switch-metaview.tooltip': 'Switch between meta and normal view',
	'Browsing' : 'Browsing',
	'Searching for' : 'Searching for',
	'in' : 'in',
	'Viewing' : 'Viewing',
	'numerous' : 'numerous',
	'of' : 'of',
	'Close' : 'Close',
	'Open' : 'Open',
	'Search' : 'Search',
	'Name' : 'Name',
	'URL' : 'URL',
	'Preview' : 'Preview',
	'No records to view' : 'No records to view',
	'Input search text...' : 'Input search text...'
} );