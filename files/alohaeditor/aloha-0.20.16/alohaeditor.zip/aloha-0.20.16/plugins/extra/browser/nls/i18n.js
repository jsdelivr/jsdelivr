define( {
	'de': true,
	'en': true
} );