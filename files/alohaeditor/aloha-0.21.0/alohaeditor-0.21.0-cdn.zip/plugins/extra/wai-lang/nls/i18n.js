define({
	root: {
		"floatingmenu.tab.wai-lang": "Language annotation",
		"button.add-wai-lang-remove.tooltip":"Remove language annotation",
		"button.add-wai-lang.tooltip":"Add language annotation",
		"insertAnnotation":"ctrl+shift+l"
	},
	"de":true,
	"en":true
});