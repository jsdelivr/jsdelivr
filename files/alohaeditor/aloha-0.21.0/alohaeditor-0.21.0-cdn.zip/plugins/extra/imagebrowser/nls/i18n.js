define({
	root: { "button.addimage.tooltip":"Insert Image",
			"button.removeimage.tooltip":"Remove Image",
			"newimage.defaulttext":"New Image",
			"floatingmenu.tab.img":"Image"}
//,	//"de":true,
//,	"fr":true //,
	//"pl":true,
	//"ru":true
});