define({
	root: {"button.createulist.tooltip":"Insert Unordered List","button.createolist.tooltip":"Insert Ordered List","button.indentlist.tooltip":"Indent List","button.outdentlist.tooltip":"Outdent List","floatingmenu.tab.list":"Lists"}
,	"de":true,
	"eo":true,
	"fi":true,
	"fr":true,
	"it":true,
	"ru":true
});