define({
	root: {"button.addhr.tooltip": "Add a horizontal ruler"},
	de:true
});