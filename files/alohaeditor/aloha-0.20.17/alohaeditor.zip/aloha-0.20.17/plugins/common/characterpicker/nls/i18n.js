define({
	root: {"button.addcharacter.tooltip": "pick special characters"},
	de: true
});