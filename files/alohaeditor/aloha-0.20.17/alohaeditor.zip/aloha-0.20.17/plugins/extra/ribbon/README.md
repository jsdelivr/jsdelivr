Aloha Ribbon Plugin
===================

This plugin is intended to provide a Ribbon for Aloha Editor.
The ribbon is displayed on top of the page and some controls can be added to it dynamically.

How-to and more informations in Aloha's Wiki :
http://aloha-editor.com/wiki/index.php/Plugins/Ribbon
