﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'gu', {
	ltr: 'ટેક્ષ્ત્ ની દિશા ડાબે થી જમણે',
	rtl: 'ટેક્ષ્ત્ ની દિશા જમણે થી ડાબે'
});
