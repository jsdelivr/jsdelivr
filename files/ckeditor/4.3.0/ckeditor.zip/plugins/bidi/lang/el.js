﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'bidi', 'el', {
	ltr: 'Διεύθυνση κειμένου από αριστερά στα δεξιά',
	rtl: 'Διεύθυνση κειμένου από δεξιά στα αριστερά'
});
