﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'it', {
	copy: 'Copyright &copy; $1. Tutti i diritti riservati.',
	dlgTitle: 'Riguardo CKEditor',
	help: 'Vedi $1 per l\'aiuto.',
	moreInfo: 'Per le informazioni sulla licenza si prega di visitare il nostro sito:',
	title: 'Riguardo CKEditor',
	userGuide: 'Guida Utente CKEditor'
});
