﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'fa', {
	copy: 'حق نشر &copy; $1. کلیه حقوق محفوظ است.',
	dlgTitle: 'درباره CKEditor',
	help: ' برای راهنمایی $1 را بررسی کنید.',
	moreInfo: 'برای کسب اطلاعات مجوز لطفا به وب سایت ما مراجعه کنید:',
	title: 'درباره CKEditor',
	userGuide: 'راهنمای کاربران CKEditor'
});
