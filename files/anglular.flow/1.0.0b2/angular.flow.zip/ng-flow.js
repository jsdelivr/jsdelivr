angular.module('ngFlow', ['ngFlow.provider', 'ngFlow.init', 'ngFlow.btn',
  'ngFlow.drop', 'ngFlow.transfers', 'ngFlow.img']);