var Ix = require('./l2o');
require('./ix');
module.exports = Ix;