/*
 * {{{name}}}
 * {{{description}}}
 * 
 * Copyright (c) 2009 - 2013 {{{author}}}
 * Source: https://github.com/dcneiner/In-Field-Labels-jQuery-Plugin
 * Dual licensed MIT or GPL
 *   MIT (http://www.opensource.org/licenses/mit-license)
 *   GPL (http://www.opensource.org/licenses/gpl-license)
 *
 * @version {{{version}}}
 */