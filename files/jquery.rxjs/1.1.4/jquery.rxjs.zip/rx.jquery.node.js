var Rx = require('rx');
require('./rx.jquery');
module.exports = Rx;