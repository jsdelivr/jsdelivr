/*
 * Requires jquery.tooltips.js
*/


(function() {
  $(function() {
    return $('.tooltip[title]').tooltip();
  });

}).call(this);
