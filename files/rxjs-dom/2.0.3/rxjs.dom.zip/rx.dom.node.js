var Rx = require('rx');
require('./rx.dom');
module.exports = Rx;