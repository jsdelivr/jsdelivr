/**
 *  Slider Kit Delay Captions, v.1.1 (packed) - 2012/01/10
 *  http://www.kyrielles.net/sliderkit
 *  
 *  Copyright (c) 2010-2012 Alan Frog
 *  Licensed under the GNU General Public License
 *  See <license.txt> or <http://www.gnu.org/licenses/>
 *  
 *  Requires : jQuery Slider Kit v1.7.1+
 * 
 */
eval(function(p,a,c,k,e,r){e=function(c){return(c<a?'':e(parseInt(c/a)))+((c=c%a)>35?String.fromCharCode(c+29):c.toString(36))};if(!''.replace(/^/,String)){while(c--)r[e(c)]=k[c]||e(c);k=[function(e){return r[e]}];e=function(){return'\\w+'};c=1};while(c--)if(k[c])p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c]);return p}('(5($){T.U.q=5(c){3 d=V,K={v:W,6:\'n\',w:\'x\',y:X,L:\'\',Y:l},r={o:d.4.Z+\'-10-o\'},2=\'\',z=0,A=\'\',j=0,s=0,t=0,k=\'\';3 e=5(){3 a=$(\'.\'+r.o,d.11);7(a.B()==0){d.C(\'q #12\',d.4.D,0);M l}2=$.13({},K,c);3 b=a.14();j=(2.6==\'u\'||2.6==\'n\')?a.15():2.6==\'m\'?b:2.6==\'p\'?d.16:0;7(j==0){d.C(\'q #17\',d.4.D,0);M l}18{a.E({u:\'\',n:\'0\',m:\'\',p:\'\'})}s=2.v<d.4.F?d.4.F:2.v;t=d.4.F+s+2.y;7(d.4.N<t){d.4.N=t;d.C(\'q #19\',d.4.D,0)}d.G=l;H(2.w){8\'x\':A=2.6==\'p\'?\'\':\'-\';z=2.6==\'p\'?\'m\':2.6;H(2.6){8\'u\':k={u:\'+=\'+j};9;8\'n\':k={n:\'+=\'+j};9;8\'m\':k={m:\'+=\'+j};9;8\'p\':k={m:\'-=\'+b};9}9;8\'O\':k={\'P\':1};9}};3 f=5(){7(d.I!=1a){1b(d.I)}};3 g=5(){f();3 a=$(\'.\'+r.o,d.Q);7(a.B()>0){H(2.w){8\'O\':a.E(\'P\',\'0\');9;8\'x\':a.E(z,A+j+\'1c\');9}}};d.1d.R(g);3 h=5(a){d.J=S;a.1e(k,2.y,2.L,5(){d.G=l;d.J=l})};3 i=5(){f();3 a=$(\'.\'+r.o,d.Q);7(a.B()>0){7(!d.4.1f){d.G=S}7(!d.J){d.I=1g(5(){h(a)},s)}}};d.1h.R(i);e()}})(1i);',62,81,'||params|var|options|function|position|if|case|break||||||||||txtboxSize|animParam|false|left|bottom|textbox|right|DelayCaptions|csslib|animDelay|animDuration|top|delay|transition|sliding|duration|cssPos|cssOp|size|_errorReport|debug|css|panelfxspeed|animating|switch|txtBoxTimer|textboxRunning|defaults|easing|return|autospeed|fading|opacity|currPanel|push|true|SliderKit|prototype|this|400|300|hold|cssprefix|panel|domObj|01|extend|width|height|domObjWidth|02|else|03|null|clearTimeout|px|panelAnteFns|animate|fastchange|setTimeout|panelPostFns|jQuery'.split('|'),0,{}))